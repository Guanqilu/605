#!/bin/bash
for file in $(ls -1 Data/MSN*.csv); do
	    cat $file >> Data/allMSN.csv
done
cat Data/allMSN.csv  |cut -d, -f3,4,5 | sort -t, -k3nr | head -n1 > out

module load R/R-3.6.1

Rscript average.R
#write the results to out
echo Mo Tu We Th Fr Sa Su >> out
echo $(cat avg.txt) >> out
rm avg.txt

