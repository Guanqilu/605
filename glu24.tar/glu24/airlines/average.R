allMSN = read.csv('Data/allMSN.csv')
allMSN = allMSN[!is.na(allMSN[, 2]), ]
avg = round(tapply(allMSN[, 2], allMSN[, 1], mean), 1)
write.table(t(avg), 'avg.txt', sep = ' ',col.names = F, row.names = F)
