#!/bin/bash

#clean all the other data  directory and output
rm -rf Data
rm -rf Out

#make new datafolder
mkdir Data
