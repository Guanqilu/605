#!/bin/bash
rm -rf out
cat out1.csv out2.csv out3.csv | sort -n | head -1 >>out
