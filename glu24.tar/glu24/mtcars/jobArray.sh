#!/bin/bash
n=$SLURM_ARRAY_TASK_ID
wt_col=7
gear_col=11
cat mtcars$n.csv | awk -F, '$'"$gear_col"'==3 { print }' | cut -f $wt_col -d , > out$n.csv
#produce 3 csv files

