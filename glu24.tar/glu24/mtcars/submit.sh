#!/bin/bash

module load R/R-3.6.1

job1=$(sbatch --output="omit" getData.sh)
job1=$(echo $job1 | sed 's/Submitted batch job //')

job2=$(sbatch --array=1-3 --output="omit" --dependency=afterany:$job1 jobArray.sh)
job2=$(echo $job2 | sed 's/Submitted batch job //')

job3=$(sbatch --output="omit" --dependency=afterany:$job2 findLightest.sh)
